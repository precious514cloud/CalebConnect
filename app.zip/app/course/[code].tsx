import { Link, useLocalSearchParams } from "expo-router";
import { Pressable, SafeAreaView, StyleSheet, Text, View } from "react-native";

export default function CourseScreen() {
  const { code } = useLocalSearchParams();

  const courses: Record<string, { title: string; units: string }> = {
    COS102: {
      title: "Problem Solving",
      units: "3 Units",
    },
    "CUL-CSC172": {
      title: "Data Mining & Warehousing",
      units: "3 Units",
    },
    "CUL-CSC176": {
      title: "Introduction to Web Design",
      units: "2 Units",
    },
    "CUL-CSC178": {
      title: "Basic Electronics",
      units: "2 Units",
    },
    GST104: {
      title: "Tech Plus I",
      units: "2 Units",
    },
    GST112: {
      title: "Nigerian Peoples and Culture",
      units: "2 Units",
    },
    MTH102: {
      title: "Elementary Mathematics II",
      units: "2 Units",
    },
    PHY102: {
      title: "General Physics II",
      units: "2 Units",
    },
    PHY108: {
      title: "General Practical Physics II",
      units: "1 Unit",
    },
  };

  const course =
    courses[code as string] || {
      title: "Unknown Course",
      units: "",
    };

  return (
    <SafeAreaView style={styles.container}>

      <Text style={styles.code}>{code}</Text>

      <Text style={styles.title}>
        {course.title}
      </Text>

      <Text style={styles.subtitle}>
        {course.units}
      </Text>
      <Link
  href={{
    pathname: "/course/lecture/[index]",
    params: { index: "1" },
  }}
  asChild
>
  <Pressable style={styles.card}>
    <Text style={styles.item}>📖 Lecture 1</Text>
  </Pressable>
</Link>
  

      <View style={styles.card}>
        <Text style={styles.item}>📝 Assignments</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.item}>📂 Resources</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.item}>📢 Announcements</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.item}>🎥 Recorded Classes (Coming Soon)</Text>
      </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
    padding: 20,
  },

  code: {
    color: "#4DA3FF",
    fontSize: 18,
    fontWeight: "700",
    marginTop: 15,
  },

  title: {
    color: "#fff",
    fontSize: 34,
    fontWeight: "700",
    marginTop: 10,
  },

  subtitle: {
    color: "#888",
    fontSize: 16,
    marginBottom: 30,
  },

  card: {
    backgroundColor: "#1C1C1E",
    padding: 20,
    borderRadius: 18,
    marginBottom: 15,
  },

  item: {
    color: "#fff",
    fontSize: 18,
  },
});